// Export SVG icons from their respective files
export { default as todo } from './To-do.svg';
export { default as add } from './add.svg';
export { default as dotmenu } from './3 dot menu.svg';
export { default as Backlog } from './Backlog.svg';
export { default as Cancelled } from './Cancelled.svg';
export { default as Display } from './Display.svg';
export { default as Done } from './Done.svg';
export { default as HighPriority } from './Img - High Priority.svg';
export { default as LowPriority } from './Img - Low Priority.svg';
export { default as MediumPriority } from './Img - Medium Priority.svg';
export { default as Nopriority } from './No-priority.svg';
export { default as UrgentPrioritycolour } from './SVG - Urgent Priority colour.svg';
export { default as UrgentPrioritygrey } from './SVG - Urgent Priority grey.svg';
export { default as down } from './down.svg';
export { default as inprogress } from './in-progress.svg';
