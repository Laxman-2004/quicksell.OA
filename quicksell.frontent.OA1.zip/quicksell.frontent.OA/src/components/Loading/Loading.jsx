import React from "react";

const Loading = () => {
  return (
    <div
      style={{
        // Set the container to cover the entire viewport
        width: "100vw",
        height: "100vh",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        flexDirection: "column",
        gap: "5px",
      }}
    >
      <span
        style={{
          // Customize the loading message appearance
          color: "green",
          fontWeight: "bolder",
          letterSpacing: "2px",
        }}
      >
        Loading...
      </span>
    </div>
  );
};

export default Loading;
